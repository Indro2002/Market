# Market POS Pro

A professional offline-first market POS application built with Node.js + SQLite + Express.

## Features
- Admin / manager / cashier login
- Products with barcode, stock, min stock, category, expiry date
- Sales and cart management
- Cash / card / cash EUR payments
- Loyalty customers
- Supplier management
- Inventory movement tracking
- Expense tracking
- Daily cash balance dashboard
- Sales history
- CSV export
- Alerts for low stock and approaching expiry

## Run locally

```bash
npm install
npm start
```

Then open:

```text
http://localhost:3000
```

Default users:
- admin / admin
- menaxher / menaxher
- kasier / kasier

## Project structure

```text
market-pos-pro/
├── package.json
├── server/
│   ├── db.js
│   └── server.js
├── public/
│   ├── index.html
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── app.js
└── README.md
```
