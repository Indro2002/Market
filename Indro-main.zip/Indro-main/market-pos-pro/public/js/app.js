const apiBase = "/api";
let cart = [];
let products = [];
let suppliers = [];
let customers = [];
let sales = [];
let expenses = [];
let inventoryLogs = [];
let currentUser = null;
let cashState = {
  cashALL: 0,
  cardALL: 0,
  cashEUR: 0,
  openingFloatALL: 0,
  kasaOpenedAt: "",
  exchangeRate: 100
};

function $id(id) { return document.getElementById(id); }
function clean(value) { return String(value ?? "").trim(); }
function money(value) { return Number(value || 0).toFixed(2); }
function normalized(value) { return clean(value).toLowerCase().replace(/\s+/g, " "); }
function escapeHtml(value) { return String(value ?? "").replace(/[&<>\"']/g, c => ({"&":"&amp;","<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"}[c])); }

function showSection(sectionId) {
  document.querySelectorAll(".section").forEach(sec => sec.classList.add("hidden"));
  const target = document.getElementById(sectionId);
  if(target){
    target.classList.remove("hidden");
    target.classList.add("active");
  }
}

function initMenuForRole(role) {
  const visible = {
    admin: ["dashboard","sale","products","suppliers","inventory","cash","expenses","history","customers"],
    manager: ["dashboard","sale","products","suppliers","inventory","cash","expenses","history","customers"],
    cashier: ["dashboard","sale","history","customers","cash"]
  };

  const allowed = visible[role] || [];
  document.querySelectorAll("#mainMenu button").forEach(btn => {
    const key = btn.dataset.section;
    if(btn.id === "logoutBtn") return;
    btn.style.display = key && allowed.includes(key) ? "inline-block" : "none";
  });
}

function renderCash(){
  $id("cashBalanceALL").textContent = money(cashState.cashALL);
  $id("cardBalanceALL").textContent = money(cashState.cardALL);
  $id("cashBalanceEUR").textContent = money(cashState.cashEUR);
  $id("activeFloat").textContent = money(cashState.openingFloatALL);
  $id("activeFloatCard").textContent = money(cashState.openingFloatALL);
  $id("dailyCashALL").textContent = money(cashState.cashALL);
  $id("dailyCardALL").textContent = money(cashState.cardALL);
  $id("dailyCashEUR").textContent = money(cashState.cashEUR);

  $id("kasaStatus").textContent = cashState.kasaOpenedAt
    ? `Hapur më ${new Date(cashState.kasaOpenedAt).toLocaleString("sq-AL")}`
    : "Kasa e mbyllur";
  $id("kasaStatus").className = cashState.kasaOpenedAt ? "green" : "red";
  $id("exchangeRateInput").value = cashState.exchangeRate;
}

function fetchJson(url, options = {}) {
  return fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options
  }).then(async response => {
    const data = await response.json().catch(() => ({}));
    if(!response.ok) throw new Error(data.error || "Request failed");
    return data;
  });
}

function login(){
  const username = clean($id("username").value);
  const password = clean($id("password").value);

  fetchJson(`${apiBase}/login`, {
    method: "POST",
    body: JSON.stringify({ username, password })
  })
    .then(data => {
      currentUser = data.user;
      $id("loginSection").classList.add("hidden");
      $id("mainMenu").classList.remove("hidden");
      $id("alertPill").classList.remove("hidden");
      initMenuForRole(currentUser.role);
      showSection("dashboard");
      loadDashboard();
      loadProducts();
      loadSuppliers();
      loadCustomers();
      loadSales();
      loadExpenses();
      loadInventory();
      renderCash();
    })
    .catch(err => {
      $id("loginMsg").textContent = err.message;
    });
}

function logout(){
  currentUser = null;
  $id("loginSection").classList.remove("hidden");
  $id("mainMenu").classList.add("hidden");
  $id("alertPill").classList.add("hidden");
  showSection("dashboard");
}

function loadProducts(){
  fetchJson(`${apiBase}/products`)
    .then(data => {
      products = data;
      renderProductsTable();
      renderSupplierOptions();
      renderInventoryOptions();
      renderAlerts();
    })
    .catch(console.error);
}

function loadSuppliers(){
  fetchJson(`${apiBase}/suppliers`)
    .then(data => {
      suppliers = data;
      renderSuppliersTable();
      renderSupplierOptions();
    })
    .catch(console.error);
}

function loadCustomers(){
  fetchJson(`${apiBase}/customers`)
    .then(data => {
      customers = data;
      renderCustomersTable();
      renderCustomerSuggestions();
    })
    .catch(console.error);
}

function loadSales(){
  fetchJson(`${apiBase}/sales`)
    .then(data => {
      sales = data;
      renderHistoryTable();
    })
    .catch(console.error);
}

function loadExpenses(){
  fetchJson(`${apiBase}/expenses`)
    .then(data => {
      expenses = data;
      renderExpensesTable();
    })
    .catch(console.error);
}

function loadInventory(){
  fetchJson(`${apiBase}/inventory`)
    .then(data => {
      inventoryLogs = data;
      renderInventoryTable();
    })
    .catch(console.error);
}

function loadDashboard(){
  fetchJson(`${apiBase}/reports/summary`)
    .then(summary => {
      const stats = [
        ["Shitje sot", `${money(summary.sales_today || 0)} ALL`],
        ["Fitimi sot", `${money(summary.profit_today || 0)} ALL`],
        ["Produkte", summary.total_products || 0],
        ["Klientë", summary.total_customers || 0],
        ["Transaksione", summary.transactions_today || 0]
      ];

      const container = $id("dashboardStats");
      container.innerHTML = stats.map(item => `
        <div class="stat">
          <div class="stat-label">${item[0]}</div>
          <div class="stat-value">${item[1]}</div>
        </div>
      `).join("");

      const table = $id("dashboardTable");
      table.innerHTML = `
        <tr><th>Produkt</th><th>Çmim</th><th>Stok</th><th>Status</th></tr>
      `;

      products.slice(0, 8).forEach(product => {
        let status = "Normal";
        if(Number(product.stock) <= Number(product.min_stock)) status = "Ulët";
        if(product.expiry && new Date(product.expiry + "T23:59:59") < new Date()) status = "Skaduar";

        table.insertAdjacentHTML("beforeend", `
          <tr>
            <td>${escapeHtml(product.name)}</td>
            <td>${money(product.price)} ALL</td>
            <td>${product.stock}</td>
            <td>${status}</td>
          </tr>
        `);
      });
    })
    .catch(console.error);
}

function renderProductsTable(){
  const table = $id("productTable");
  if(!table) return;

  table.innerHTML = `
    <tr>
      <th>Emri</th><th>Barkod</th><th>Njësia</th><th>Çmim</th><th>Kosto</th><th>Stok</th><th>Min</th><th>Kategori</th><th>Skadenca</th><th>Furnitor</th><th>Fshi</th>
    </tr>
  `;

  products.forEach(product => {
    let rowClass = "";
    let alarm = "—";
    if(product.expiry){
      const expiry = new Date(product.expiry + "T23:59:59");
      const diffDays = Math.ceil((expiry - new Date()) / 86400000);
      if(expiry < new Date()){
        rowClass = "expired";
        alarm = "<span class='red'>Skaduar</span>";
      } else if(diffDays <= 7){
        rowClass = "expiring";
        alarm = `<span class='warn'>Skadon ${diffDays}d</span>`;
      }
    }

    if(Number(product.stock) <= Number(product.min_stock)){
      rowClass = rowClass || "lowstock";
      alarm = alarm === "—" ? "<span class='red'>Stok i ulët</span>" : alarm + " • <span class='red'>Stok i ulët</span>";
    }

    const supplierName = suppliers.find(s => s.id == product.supplier_id)?.name || "—";

    table.insertAdjacentHTML("beforeend", `
      <tr class="${rowClass}">
        <td><input value="${escapeHtml(product.name)}" data-field="name" data-id="${product.id}" class="editable-field" /></td>
        <td><input value="${escapeHtml(product.barcode)}" data-field="barcode" data-id="${product.id}" class="editable-field" /></td>
        <td>
          <select data-field="unit" data-id="${product.id}">
            <option value="piece" ${product.unit === "piece" ? "selected" : ""}>Copë</option>
            <option value="kg" ${product.unit === "kg" ? "selected" : ""}>Kg</option>
          </select>
        </td>
        <td><input type="number" min="0" step=".01" value="${product.price}" data-field="price" data-id="${product.id}" class="editable-field" /></td>
        <td><input type="number" min="0" step=".01" value="${product.cost}" data-field="cost" data-id="${product.id}" class="editable-field" /></td>
        <td><input type="number" min="0" step=".001" value="${product.stock}" data-field="stock" data-id="${product.id}" class="editable-field" /></td>
        <td><input type="number" min="0" step=".001" value="${product.min_stock}" data-field="min_stock" data-id="${product.id}" class="editable-field" /></td>
        <td>
          <select data-field="category" data-id="${product.id}">
            <option value="ushqim" ${product.category === "ushqim" ? "selected" : ""}>Ushqim</option>
            <option value="pije" ${product.category === "pije" ? "selected" : ""}>Pije</option>
            <option value="higjienike" ${product.category === "higjienike" ? "selected" : ""}>Higjienike</option>
          </select>
        </td>
        <td><input type="date" value="${product.expiry || ""}" data-field="expiry" data-id="${product.id}" class="editable-field" /></td>
        <td>
          <select data-field="supplier_id" data-id="${product.id}">
            <option value="">—</option>
            ${suppliers.map(s => `<option value="${s.id}" ${product.supplier_id == s.id ? "selected" : ""}>${escapeHtml(s.name)}</option>`).join("")}
          </select>
        </td>
        <td><button class="danger" data-delete-id="${product.id}">🗑️</button></td>
      </tr>
    `);
  });

  table.querySelectorAll(".editable-field").forEach(input => {
    input.addEventListener("change", handleProductEdit);
  });

  table.querySelectorAll("[data-field]").forEach(el => {
    if(el.tagName === "SELECT") {
      el.addEventListener("change", handleProductEdit);
    }
  });

  table.querySelectorAll("[data-delete-id]").forEach(btn => {
    btn.addEventListener("click", () => deleteProduct(btn.dataset.deleteId));
  });
}

function handleProductEdit(event){
  const id = event.target.dataset.id;
  const field = event.target.dataset.field;
  const value = event.target.value;

  const product = products.find(p => p.id == id);
  if(!product) return;

  if(field === "name" || field === "barcode" || field === "expiry" || field === "supplier_id"){
    product[field] = value;
  } else if(field === "unit" || field === "category"){
    product[field] = value;
  } else if(["price","cost","stock","min_stock"].includes(field)){
    product[field] = Number(value || 0);
  }

  fetchJson(`${apiBase}/products/${id}`, {
    method: "PUT",
    body: JSON.stringify(product)
  })
    .then(() => {
      loadProducts();
      loadDashboard();
    })
    .catch(console.error);
}

function deleteProduct(id){
  if(!confirm("Fshi produktin?")) return;

  fetchJson(`${apiBase}/products/${id}`, { method: "DELETE" })
    .then(() => {
      loadProducts();
      loadDashboard();
    })
    .catch(console.error);
}

function addProduct(){
  const product = {
    name: clean($id("prodName").value),
    barcode: clean($id("prodBarcode").value),
    unit: $id("prodUnit").value,
    price: Number($id("prodPrice").value || 0),
    cost: Number($id("prodCost").value || 0),
    stock: Number($id("prodStock").value || 0),
    min_stock: Number($id("prodMin").value || 0),
    category: $id("prodCategory").value,
    expiry: $id("prodExpiry").value,
    supplier_id: $id("prodSupplier").value || null
  };

  if(!product.name || !product.barcode){
    alert("Emri dhe barkodi janë të detyrueshëm.");
    return;
  }

  fetchJson(`${apiBase}/products`, {
    method: "POST",
    body: JSON.stringify(product)
  })
    .then(() => {
      $id("prodName").value = "";
      $id("prodBarcode").value = "";
      $id("prodPrice").value = "";
      $id("prodCost").value = "";
      $id("prodStock").value = "";
      $id("prodMin").value = "";
      $id("prodExpiry").value = "";
      loadProducts();
      loadDashboard();
    })
    .catch(console.error);
}

function renderSupplierOptions(){
  const prodSelect = $id("prodSupplier");
  if(prodSelect){
    prodSelect.innerHTML = `<option value="">—</option>` + suppliers.map(s => `<option value="${s.id}">${escapeHtml(s.name)}</option>`).join("");
  }

  const inventorySelect = $id("inventoryProduct");
  if(inventorySelect){
    inventorySelect.innerHTML = products.map(p => `<option value="${p.id}">${escapeHtml(p.name)}</option>`).join("");
  }
}

function renderSuppliersTable(){
  const table = $id("supplierTable");
  if(!table) return;

  table.innerHTML = `
    <tr><th>Emri</th><th>Telefoni</th><th>Adresa</th><th>Krijuar</th></tr>
  `;

  suppliers.forEach(s => {
    table.insertAdjacentHTML("beforeend", `
      <tr>
        <td>${escapeHtml(s.name)}</td>
        <td>${escapeHtml(s.phone)}</td>
        <td>${escapeHtml(s.address)}</td>
        <td>${new Date(s.created_at).toLocaleString("sq-AL")}</td>
      </tr>
    `);
  });
}

function addSupplier(){
  const name = clean($id("suppName").value);
  const phone = clean($id("suppPhone").value);
  const address = clean($id("suppAddress").value);

  if(!name){
    alert("Emri është i detyrueshëm.");
    return;
  }

  fetchJson(`${apiBase}/suppliers`, {
    method: "POST",
    body: JSON.stringify({ name, phone, address })
  })
    .then(() => {
      $id("suppName").value = "";
      $id("suppPhone").value = "";
      $id("suppAddress").value = "";
      loadSuppliers();
      loadProducts();
    })
    .catch(console.error);
}

function renderInventoryOptions(){
  const inventorySelect = $id("inventoryProduct");
  if(inventorySelect){
    inventorySelect.innerHTML = products.map(p => `<option value="${p.id}">${escapeHtml(p.name)}</option>`).join("");
  }
}

function renderInventoryTable(){
  const table = $id("inventoryTable");
  if(!table) return;

  table.innerHTML = `
    <tr><th>Data</th><th>Produkt</th><th>Sasia</th><th>Lloji</th><th>Shënim</th></tr>
  `;

  inventoryLogs.forEach(item => {
    const product = products.find(p => p.id == item.product_id);
    table.insertAdjacentHTML("beforeend", `
      <tr>
        <td>${new Date(item.timestamp).toLocaleString("sq-AL")}</td>
        <td>${escapeHtml(product ? product.name : "--")}</td>
        <td>${item.qty}</td>
        <td class="${item.type === "in" ? "green" : "red"}">${item.type === "in" ? "Hyrje" : "Dalje"}</td>
        <td>${escapeHtml(item.note || "-")}</td>
      </tr>
    `);
  });
}

function processInventory(){
  const product_id = $id("inventoryProduct").value;
  const qty = Number($id("inventoryQty").value || 0);
  const type = $id("inventoryType").value;
  const note = clean($id("inventoryNote").value);

  if(!product_id || qty <= 0){
    alert("Zgjidh produkt dhe vendos sasi të vlefshme.");
    return;
  }

  fetchJson(`${apiBase}/inventory`, {
    method: "POST",
    body: JSON.stringify({ product_id, type, qty, note })
  })
    .then(() => {
      $id("inventoryQty").value = "";
      $id("inventoryNote").value = "";
      loadInventory();
      loadProducts();
      loadDashboard();
    })
    .catch(console.error);
}

function openCash(){
  const amount = Number($id("openingFloatInput").value || 0);
  if(amount < 0){
    alert("Thyerja nuk mund të jetë negative.");
    return;
  }

  cashState.openingFloatALL = amount;
  cashState.kasaOpenedAt = new Date().toISOString();
  renderCash();
  showTxn("Hapja e Kasës", `<div class="green">Kasa u hap me thyerje ${money(amount)} ALL.</div>`);
}

function saveExchangeRate(){
  const value = Number($id("exchangeRateInput").value || 0);
  if(value <= 0){
    alert("Kurs i pavlefshëm.");
    return;
  }

  cashState.exchangeRate = value;
  renderCash();
  showTxn("Kursi", `<div class="green">1 EUR = ${money(value)} ALL</div>`);
}

function closeDay(){
  const realCashALL = Number($id("realCashALL").value || 0);
  const realCashEUR = Number($id("realCashEUR").value || 0);

  const expected = cashState.openingFloatALL + cashState.cashALL;
  const diffAll = realCashALL - expected;
  const diffEur = realCashEUR - cashState.cashEUR;

  showTxn("Mbyllje Dite", `
    <div class="green">Mbyllja e ditës u krye.</div>
    <p>Thyerja: <b>${money(cashState.openingFloatALL)} ALL</b></p>
    <p>Cash ALL: <b>${money(cashState.cashALL)} ALL</b></p>
    <p>Kartë: <b>${money(cashState.cardALL)} ALL</b></p>
    <p>Cash EUR: <b>${money(cashState.cashEUR)} EUR</b></p>
    <p>Arka reale ALL: <b>${money(realCashALL)} ALL</b></p>
    <p>Arka reale EUR: <b>${money(realCashEUR)} EUR</b></p>
    <p>Diferenca ALL: <b class="${diffAll >= 0 ? "green" : "red"}">${diffAll >= 0 ? "+" : "-"}${money(Math.abs(diffAll))} ALL</b></p>
    <p>Diferenca EUR: <b class="${diffEur >= 0 ? "green" : "red"}">${diffEur >= 0 ? "+" : "-"}${money(Math.abs(diffEur))} EUR</b></p>
  `);

  cashState.cashALL = 0;
  cashState.cardALL = 0;
  cashState.cashEUR = 0;
  cashState.openingFloatALL = 0;
  cashState.kasaOpenedAt = "";
  renderCash();
}

function renderHistoryTable(){
  const table = $id("historyTable");
  if(!table) return;

  table.innerHTML = `
    <tr><th>Data</th><th>Klient</th><th>Total</th><th>Paguar</th><th>Borxh</th><th>Mënyra</th><th>Veprim</th></tr>
  `;

  sales.forEach((sale, index) => {
    table.insertAdjacentHTML("beforeend", `
      <tr>
        <td>${new Date(sale.timestamp).toLocaleString("sq-AL")}</td>
        <td>${escapeHtml(sale.customer_id ? customers.find(c => c.id == sale.customer_id)?.name || "--" : "--")}</td>
        <td>${money(sale.total_all)} ALL</td>
        <td>${money(sale.amount_paid)} ALL</td>
        <td>${money(sale.due)} ALL</td>
        <td>${escapeHtml(sale.payment_method)}</td>
        <td><button class="secondary" data-view-sale="${index}">Shiko</button></td>
      </tr>
    `);
  });

  table.querySelectorAll("[data-view-sale]").forEach(btn => {
    btn.addEventListener("click", () => {
      const sale = sales[Number(btn.dataset.viewSale)];
      if(!sale) return;
      showTxn("Detajet e Shitjes", `
        <p><b>Data:</b> ${new Date(sale.timestamp).toLocaleString("sq-AL")}</p>
        <p><b>Klient:</b> ${escapeHtml(customers.find(c => c.id == sale.customer_id)?.name || "--")}</p>
        <p><b>Total:</b> ${money(sale.total_all)} ALL</p>
        <p><b>Paguar:</b> ${money(sale.amount_paid)} ALL</p>
        <p><b>Borxh:</b> ${money(sale.due)} ALL</p>
        <p><b>Mënyra:</b> ${escapeHtml(sale.payment_method)}</p>
      `);
    });
  });
}

function renderCustomersTable(){
  const table = $id("customerTable");
  if(!table) return;

  table.innerHTML = `<tr><th>Emri</th><th>Telefon</th><th>Pikët</th><th>Shpenzuar</th></tr>`;

  const q = normalized($id("customerSearch").value || "");
  const filtered = customers.filter(c => !q || normalized(`${c.name} ${c.phone}`).includes(q));

  filtered.forEach(c => {
    table.insertAdjacentHTML("beforeend", `
      <tr>
        <td>${escapeHtml(c.name || "--")}</td>
        <td>${escapeHtml(c.phone || "--")}</td>
        <td>${c.points || 0}</td>
        <td>${money(c.total_spent || 0)} ALL</td>
      </tr>
    `);
  });
}

function renderExpensesTable(){
  const table = $id("expenseTable");
  if(!table) return;

  table.innerHTML = `<tr><th>Emri</th><th>Shuma</th><th>Lloji</th><th>Data</th></tr>`;
  expenses.forEach(item => {
    table.insertAdjacentHTML("beforeend", `
      <tr>
        <td>${escapeHtml(item.name)}</td>
        <td>${money(item.amount)} ALL</td>
        <td>${escapeHtml(item.type)}</td>
        <td>${new Date(item.timestamp).toLocaleString("sq-AL")}</td>
      </tr>
    `);
  });
}

function addExpense(){
  const name = clean($id("expenseName").value);
  const amount = Number($id("expenseAmount").value || 0);
  const type = $id("expenseType").value;

  if(!name || amount <= 0){
    alert("Vendos emrin dhe shumën e shpenzimit.");
    return;
  }

  fetchJson(`${apiBase}/expenses`, {
    method: "POST",
    body: JSON.stringify({ name, amount, type })
  })
    .then(() => {
      $id("expenseName").value = "";
      $id("expenseAmount").value = "";
      loadExpenses();
    })
    .catch(console.error);
}

function findProductByInput(value){
  const q = normalized(value || "");
  if(!q) return null;

  const byBarcode = products.find(p => normalized(p.barcode) === q);
  if(byBarcode) return byBarcode;

  return products.find(p => normalized(p.name).includes(q));
}

function manualAdd(){
  const product = findProductByInput($id("saleSearch").value);
  if(!product){
    alert("Produkti nuk u gjet.");
    return;
  }

  const qty = product.unit === "kg" ? Number($id("saleWeight").value || 0) : 1;
  if(product.unit === "kg" && qty <= 0){
    alert("Vendos peshën në kg.");
    return;
  }

  if(Number(product.stock) < qty){
    alert("Sasia/pesha tejkalon stokun.");
    return;
  }

  const existing = cart.find(item => item.product_id === product.id);

  if(existing){
    if(existing.qty + qty > Number(product.stock)){
      alert("Sasia/pesha tejkalon stokun.");
      return;
    }
    existing.qty += qty;
  } else {
    cart.push({
      product_id: product.id,
      name: product.name,
      price: Number(product.price),
      cost: Number(product.cost),
      qty,
      unit: product.unit
    });
  }

  $id("saleSearch").value = "";
  $id("saleWeight").value = "";
  renderCart();
}

function renderCart(){
  const table = $id("cartTable");
  if(!table) return;

  table.innerHTML = `
    <tr><th>Produkt</th><th>Sasi</th><th>Çmim</th><th>Total</th><th>Fshi</th></tr>
  `;

  cart.forEach((item, index) => {
    table.insertAdjacentHTML("beforeend", `
      <tr>
        <td>${escapeHtml(item.name)}</td>
        <td>
          <button class="secondary" data-dec="${index}">➖</button>
          ${item.unit === "kg" ? `${item.qty.toFixed(3)} kg` : `${item.qty} copë`}
          <button class="secondary" data-inc="${index}">➕</button>
        </td>
        <td>${money(item.price)} ALL</td>
        <td>${money(item.qty * item.price)} ALL</td>
        <td><button class="danger" data-remove="${index}">🗑️</button></td>
      </tr>
    `);
  });

  table.querySelectorAll("[data-dec]").forEach(btn => btn.addEventListener("click", () => adjustQty(Number(btn.dataset.dec), -1)));
  table.querySelectorAll("[data-inc]").forEach(btn => btn.addEventListener("click", () => adjustQty(Number(btn.dataset.inc), 1)));
  table.querySelectorAll("[data-remove]").forEach(btn => btn.addEventListener("click", () => {
    cart.splice(Number(btn.dataset.remove), 1);
    renderCart();
  }));

  recalcSaleTotals();
}

function adjustQty(index, delta){
  const item = cart[index];
  if(!item) return;

  const step = item.unit === "kg" ? 0.001 : 1;
  item.qty += delta * step;
  if(item.qty <= 0){
    cart.splice(index, 1);
  }
  renderCart();
}

function getCustomerFromForm(create = false){
  const name = clean($id("customerName").value);
  const phone = clean($id("customerPhone").value);

  if(!name && !phone) return null;

  const key = `${normalized(name)}|${normalized(phone)}`;
  const existing = customers.find(c => `${normalized(c.name)}|${normalized(c.phone)}` === key);

  if(existing) return existing;
  if(create){
    const newCustomer = { id: Date.now(), name, phone, points: 0, total_spent: 0 };
    customers.push(newCustomer);
    return newCustomer;
  }
  return null;
}

function recalcSaleTotals(){
  const subtotal = cart.reduce((sum, item) => sum + (item.qty * item.price), 0);
  const surchargePct = Number($id("surcharge").value || 0);
  const surcharge = subtotal * surchargePct / 100;
  const before = subtotal + surcharge;

  const customer = getCustomerFromForm(false);
  let loyaltyAmount = 0;
  if($id("useLoyalty").checked && customer && Number(customer.points || 0) > 0){
    loyaltyAmount = Math.min(Number(customer.points || 0), before);
  }

  const total = Math.max(0, before - loyaltyAmount);
  $id("totalDisplay").textContent = money(total);

  if($id("saleCurrency").value === "EUR"){
    $id("totalInEur").innerHTML = `Total EUR: <b>${money(total / cashState.exchangeRate)} EUR</b>`;
  } else {
    $id("totalInEur").innerHTML = "";
  }

  const paid = Number($id("paidAmount").value || 0);
  const paidALL = $id("paymentMethod").value === "cash_eur" ? paid * cashState.exchangeRate : paid;
  const diff = paidALL - total;
  $id("changeDisplay").textContent = diff < 0 ? `Mungojnë ${money(Math.abs(diff))} ALL` : `Kusur ${money(diff)} ALL`;
  $id("changeDisplay").className = diff < 0 ? "red" : "green";

  if(customer){
    $id("loyaltyInfo").innerHTML = `
      Klienti: <b>${escapeHtml(customer.name || "--")}</b><br>
      Pikë aktuale: <span class='green'>${customer.points || 0}</span><br>
      Shpenzuar: <b>${money(customer.total_spent || 0)} ALL</b>
    `;
    $id("useLoyalty").disabled = Number(customer.points || 0) <= 0;
  } else {
    $id("loyaltyInfo").textContent = "Vendos emrin ose telefonin e klientit për të parë pikët.";
    $id("useLoyalty").disabled = true;
    $id("useLoyalty").checked = false;
  }

  $id("loyaltyDiscount").innerHTML = loyaltyAmount > 0 ? `<span class="green">Zbritje: -${money(loyaltyAmount)} ALL</span>` : "";
}

function paySale(){
  if(!cashState.kasaOpenedAt){
    alert("Kasa nuk është hapur. Hap kasën nga seksioni Kasa.");
    return;
  }

  if(cart.length === 0){
    alert("Shporta është bosh.");
    return;
  }

  const subtotal = cart.reduce((sum, item) => sum + item.qty * item.price, 0);
  const surchargePct = Number($id("surcharge").value || 0);
  const surcharge = subtotal * surchargePct / 100;
  const customer = getCustomerFromForm(false);

  let loyaltyAmount = 0;
  if($id("useLoyalty").checked && customer && Number(customer.points || 0) > 0){
    loyaltyAmount = Math.min(Number(customer.points || 0), subtotal + surcharge);
  }

  const total = Math.max(0, subtotal + surcharge - loyaltyAmount);
  const method = $id("paymentMethod").value;
  const rawPaid = Number($id("paidAmount").value || 0);

  const paidALL = method === "cash_eur" ? rawPaid * cashState.exchangeRate : rawPaid;
  const amountPaid = Math.min(Math.max(0, paidALL), total);
  const changeAll = method === "card" ? 0 : Math.max(0, paidALL - total);
  const due = Math.max(0, total - paidALL);

  const profit = cart.reduce((sum, item) => {
    const product = products.find(p => p.id === item.product_id);
    if(!product) return sum;
    return sum + ((item.price - product.cost) * item.qty);
  }, 0);

  const payload = {
    customer_id: customer ? customer.id : null,
    total_all: total,
    amount_paid: amountPaid,
    due,
    payment_method: method,
    cash_given_raw: rawPaid,
    change_all: changeAll,
    profit,
    items: cart.map(item => ({
      product_id: item.product_id,
      qty: item.qty,
      price: item.price,
      cost: products.find(p => p.id === item.product_id)?.cost || 0
    }))
  };

  fetchJson(`${apiBase}/sales`, {
    method: "POST",
    body: JSON.stringify(payload)
  })
    .then(() => {
      if(customer){
        const earned = Math.floor(amountPaid / 100);
        customer.points = Math.max(0, (Number(customer.points || 0) - loyaltyAmount) + earned);
        customer.total_spent = Number(customer.total_spent || 0) + amountPaid;
      }

      cart = [];
      $id("saleSearch").value = "";
      $id("saleWeight").value = "";
      $id("customerName").value = "";
      $id("customerPhone").value = "";
      $id("paidAmount").value = "";
      $id("surcharge").value = "0";
      $id("useLoyalty").checked = false;
      renderCart();
      loadProducts();
      loadSales();
      loadCustomers();
      loadDashboard();

      const report = `
        <div class="${due <= 0 ? "green" : "warn"}">${due <= 0 ? "Transaksioni u mbyll me sukses." : "Shitja u regjistrua si borxh."}</div>
        <p><b>Total:</b> ${money(total)} ALL</p>
        <p><b>Klienti dha:</b> ${money(rawPaid)} ${method === "cash_eur" ? "EUR" : "ALL"}</p>
        <p><b>Paguar:</b> ${money(amountPaid)} ALL</p>
        <p><b>Kusur:</b> ${money(changeAll)} ALL</p>
        <p><b>Borxh:</b> ${money(due)} ALL</p>
      `;
      showTxn(due <= 0 ? "Shitje e plotë" : "Shitje me borxh", report);
    })
    .catch(console.error);
}

function cancelSale(){
  cart = [];
  $id("saleSearch").value = "";
  $id("saleWeight").value = "";
  $id("customerName").value = "";
  $id("customerPhone").value = "";
  $id("paidAmount").value = "";
  $id("surcharge").value = "0";
  $id("useLoyalty").checked = false;
  renderCart();
}

function renderAlerts(){
  const alerts = [];
  products.forEach(product => {
    if(Number(product.stock) <= Number(product.min_stock)) alerts.push(`Stok i ulët: ${product.name}`);
    if(product.expiry){
      const expiry = new Date(product.expiry + "T23:59:59");
      const diff = Math.ceil((expiry - new Date()) / 86400000);
      if(expiry < new Date()) alerts.push(`Skaduar: ${product.name}`);
      else if(diff <= 7) alerts.push(`Skadon së shpejti: ${product.name} (${diff} ditë)`);
    }
  });

  $id("alertCount").textContent = alerts.length;
  $id("alertsBody").innerHTML = alerts.length ? "<ul>" + alerts.map(a => `<li>${escapeHtml(a)}</li>`).join("") + "</ul>" : "<p>Nuk ka alarme.</p>";
}

function openAlertsModal(){
  renderAlerts();
  $id("alertsModal").style.display = "block";
}

function closeAlertsModal(){
  $id("alertsModal").style.display = "none";
}

function showTxn(title, html){
  $id("txnTitle").textContent = title;
  $id("txnMsg").innerHTML = html;
  $id("txnModal").style.display = "block";
}

function closeTxn(){
  $id("txnModal").style.display = "none";
}

function exportSalesCSV(){
  if(!sales.length){
    alert("Nuk ka shitje.");
    return;
  }

  const rows = [["id","timestamp","customer_id","total_all","amount_paid","due","payment_method"]];
  sales.forEach(sale => rows.push([sale.id, sale.timestamp, sale.customer_id || "", sale.total_all, sale.amount_paid, sale.due, sale.payment_method]));
  const csv = "\uFEFF" + rows.map(row => row.map(v => `"${String(v ?? "").replace(/"/g,'""')}"`).join(",")).join("\n");

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "sales_history.csv";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function exportCustomersCSV(){
  const rows = [["name","phone","points","total_spent"]];
  customers.forEach(c => rows.push([c.name || "", c.phone || "", c.points || 0, c.total_spent || 0]));
  const csv = "\uFEFF" + rows.map(row => row.map(v => `"${String(v ?? "").replace(/"/g,'""')}"`).join(",")).join("\n");

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "customers.csv";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function renderCustomerSuggestions(){
  const query = normalized(`${$id("customerName").value} ${$id("customerPhone").value}`);
  const box = $id("customerResults");

  if(!query){
    box.style.display = "none";
    box.innerHTML = "";
    return;
  }

  const matches = customers.filter(c => normalized(`${c.name} ${c.phone}`).includes(query)).slice(0, 8);
  if(!matches.length){
    box.style.display = "none";
    box.innerHTML = "";
    return;
  }

  box.innerHTML = matches.map(c => `
    <div class="result-row">
      <div>
        <b>${escapeHtml(c.name || "--")}</b><br>
        <span class="small">${escapeHtml(c.phone || "--")} · ${c.points || 0} pikë</span>
      </div>
      <button class="secondary" data-select-customer="${c.id}">Zgjidh</button>
    </div>
  `).join("");
  box.style.display = "block";

  box.querySelectorAll("[data-select-customer]").forEach(btn => {
    btn.addEventListener("click", () => {
      const customer = customers.find(c => c.id == btn.dataset.selectCustomer);
      if(!customer) return;
      $id("customerName").value = customer.name || "";
      $id("customerPhone").value = customer.phone || "";
      box.style.display = "none";
      recalcSaleTotals();
    });
  });
}

function bindEvents(){
  $id("loginBtn").addEventListener("click", login);
  $id("logoutBtn").addEventListener("click", logout);

  document.querySelectorAll("[data-section]").forEach(btn => {
    btn.addEventListener("click", () => showSection(btn.dataset.section));
  });

  $id("addManualBtn").addEventListener("click", manualAdd);
  $id("payBtn").addEventListener("click", paySale);
  $id("cancelSaleBtn").addEventListener("click", cancelSale);
  $id("addProductBtn").addEventListener("click", addProduct);
  $id("addSupplierBtn").addEventListener("click", addSupplier);
  $id("processInventoryBtn").addEventListener("click", processInventory);
  $id("openCashBtn").addEventListener("click", openCash);
  $id("saveRateBtn").addEventListener("click", saveExchangeRate);
  $id("closeDayBtn").addEventListener("click", closeDay);
  $id("addExpenseBtn").addEventListener("click", addExpense);
  $id("exportSalesBtn").addEventListener("click", exportSalesCSV);
  $id("exportCustomersBtn").addEventListener("click", exportCustomersCSV);
  $id("clearHistoryBtn").addEventListener("click", () => {
    if(confirm("Je i sigurt? Do të fshihet historiku i shitjeve.")){
      sales = [];
      renderHistoryTable();
    }
  });
  $id("searchCustomersBtn").addEventListener("click", renderCustomersTable);
  $id("clearCustomerSearchBtn").addEventListener("click", () => {
    $id("customerSearch").value = "";
    renderCustomersTable();
  });
  $id("closeAlertsBtn").addEventListener("click", closeAlertsModal);
  $id("closeTxnBtn").addEventListener("click", closeTxn);
  $id("alertPill").addEventListener("click", openAlertsModal);

  $id("saleSearch").addEventListener("keydown", e => {
    if(e.key === "Enter") {
      e.preventDefault();
      manualAdd();
    }
  });

  $id("paidAmount").addEventListener("input", recalcSaleTotals);
  $id("surcharge").addEventListener("input", recalcSaleTotals);
  $id("useLoyalty").addEventListener("change", recalcSaleTotals);
  $id("paymentMethod").addEventListener("change", () => {
    $id("saleCurrency").value = $id("paymentMethod").value === "cash_eur" ? "EUR" : "ALL";
    recalcSaleTotals();
  });

  $id("customerName").addEventListener("input", renderCustomerSuggestions);
  $id("customerPhone").addEventListener("input", renderCustomerSuggestions);
  $id("customerSearch").addEventListener("input", renderCustomersTable);

  document.addEventListener("keydown", event => {
    if(event.key === "Escape") {
      $id("alertsModal").style.display = "none";
      $id("txnModal").style.display = "none";
    }
  });
}

function init(){
  bindEvents();
  renderCash();
  loadProducts();
  loadSuppliers();
  loadCustomers();
  loadSales();
  loadExpenses();
  loadInventory();
  renderAlerts();
  renderCustomersTable();
  renderHistoryTable();
  renderExpensesTable();
  renderInventoryTable();
}

window.addEventListener("load", init);
