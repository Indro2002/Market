const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const dbPath = path.join(__dirname, "market.db");
const db = new sqlite3.Database(dbPath);

function initDB() {
  db.serialize(() => {
    db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        role TEXT
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS suppliers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        phone TEXT,
        address TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        barcode TEXT UNIQUE,
        unit TEXT,
        price REAL,
        cost REAL,
        stock REAL,
        min_stock REAL,
        category TEXT,
        expiry TEXT,
        supplier_id INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        phone TEXT,
        points INTEGER DEFAULT 0,
        total_spent REAL DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT,
        customer_id INTEGER,
        total_all REAL,
        amount_paid REAL,
        due REAL,
        payment_method TEXT,
        cash_given_raw REAL,
        change_all REAL,
        profit REAL,
        status TEXT DEFAULT 'paid'
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS sale_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sale_id INTEGER,
        product_id INTEGER,
        qty REAL,
        price REAL,
        cost REAL
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS inventory_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER,
        type TEXT,
        qty REAL,
        note TEXT,
        timestamp TEXT
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        amount REAL,
        type TEXT,
        timestamp TEXT
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS cash_movements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT,
        amount REAL,
        note TEXT,
        timestamp TEXT
      )
    `);

    db.run(`
      INSERT OR IGNORE INTO users (username, password, role)
      VALUES
      ('admin', 'admin', 'admin'),
      ('menaxher', 'menaxher', 'manager'),
      ('kasier', 'kasier', 'cashier')
    `);

    db.run(`
      INSERT OR IGNORE INTO suppliers (id, name, phone, address) VALUES
      (1, 'Furnitori A', '0671234567', 'Rruga 1'),
      (2, 'Furnitori B', '0687654321', 'Rruga 2')
    `);

    db.run(`
      INSERT OR IGNORE INTO products (id, name, barcode, unit, price, cost, stock, min_stock, category, expiry, supplier_id)
      VALUES
      (1, 'Mleke', '1001', 'piece', 80, 55, 25, 8, 'ushqim', '2026-12-10', 1),
      (2, 'Ujë', '1002', 'piece', 40, 25, 40, 10, 'pije', '2027-01-15', 2),
      (3, 'Shampon', '1003', 'piece', 220, 140, 10, 4, 'higjienike', '2027-03-01', 1),
      (4, 'Domate', '1004', 'kg', 150, 90, 7, 3, 'ushqim', '2026-10-20', 2)
    `);

    db.run(`
      INSERT OR IGNORE INTO customers (id, name, phone, points, total_spent)
      VALUES
      (1, 'Test Klient', '0670000000', 120, 3200)
    `);
  });
}

module.exports = { db, initDB };
