const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");
const { db, initDB } = require("./db");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "..", "public")));

initDB();

app.get("/api/health", (req, res) => {
  res.json({ ok: true, message: "POS server running" });
});

app.post("/api/login", (req, res) => {
  const { username, password } = req.body;

  db.get(
    "SELECT * FROM users WHERE username = ? AND password = ?",
    [username, password],
    (err, row) => {
      if (err) return res.status(500).json({ error: err.message });
      if (!row) return res.status(401).json({ error: "Invalid credentials" });

      res.json({
        ok: true,
        user: {
          id: row.id,
          username: row.username,
          role: row.role
        }
      });
    }
  );
});

app.get("/api/products", (req, res) => {
  db.all("SELECT * FROM products ORDER BY id DESC", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post("/api/products", (req, res) => {
  const {
    name,
    barcode,
    unit,
    price,
    cost,
    stock,
    min_stock,
    category,
    expiry,
    supplier_id
  } = req.body;

  db.run(
    `INSERT INTO products (name, barcode, unit, price, cost, stock, min_stock, category, expiry, supplier_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [name, barcode, unit, price, cost, stock, min_stock, category, expiry, supplier_id],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ ok: true, id: this.lastID });
    }
  );
});

app.put("/api/products/:id", (req, res) => {
  const { id } = req.params;
  const {
    name,
    barcode,
    unit,
    price,
    cost,
    stock,
    min_stock,
    category,
    expiry,
    supplier_id
  } = req.body;

  db.run(
    `UPDATE products
     SET name = ?, barcode = ?, unit = ?, price = ?, cost = ?, stock = ?, min_stock = ?, category = ?, expiry = ?, supplier_id = ?
     WHERE id = ?`,
    [name, barcode, unit, price, cost, stock, min_stock, category, expiry, supplier_id, id],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ ok: true, updated: this.changes });
    }
  );
});

app.delete("/api/products/:id", (req, res) => {
  db.run("DELETE FROM products WHERE id = ?", [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ ok: true, deleted: this.changes });
  });
});

app.get("/api/suppliers", (req, res) => {
  db.all("SELECT * FROM suppliers ORDER BY id DESC", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post("/api/suppliers", (req, res) => {
  const { name, phone, address } = req.body;
  db.run(
    "INSERT INTO suppliers (name, phone, address) VALUES (?, ?, ?)",
    [name, phone, address],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ ok: true, id: this.lastID });
    }
  );
});

app.get("/api/customers", (req, res) => {
  db.all("SELECT * FROM customers ORDER BY id DESC", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post("/api/customers", (req, res) => {
  const { name, phone } = req.body;
  db.run(
    "INSERT INTO customers (name, phone) VALUES (?, ?)",
    [name, phone],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ ok: true, id: this.lastID });
    }
  );
});

app.get("/api/expenses", (req, res) => {
  db.all("SELECT * FROM expenses ORDER BY id DESC", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post("/api/expenses", (req, res) => {
  const { name, amount, type } = req.body;
  db.run(
    "INSERT INTO expenses (name, amount, type, timestamp) VALUES (?, ?, ?, ?)",
    [name, amount, type, new Date().toISOString()],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ ok: true, id: this.lastID });
    }
  );
});

app.get("/api/inventory", (req, res) => {
  db.all("SELECT * FROM inventory_log ORDER BY id DESC", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post("/api/inventory", (req, res) => {
  const { product_id, type, qty, note } = req.body;

  db.run(
    "INSERT INTO inventory_log (product_id, type, qty, note, timestamp) VALUES (?, ?, ?, ?, ?)",
    [product_id, type, qty, note, new Date().toISOString()],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });

      if (type === "in") {
        db.run("UPDATE products SET stock = stock + ? WHERE id = ?", [qty, product_id], function (innerErr) {
          if (innerErr) return res.status(500).json({ error: innerErr.message });
          res.json({ ok: true, id: this.lastID });
        });
      } else {
        db.run("UPDATE products SET stock = MAX(stock - ?, 0) WHERE id = ?", [qty, product_id], function (innerErr) {
          if (innerErr) return res.status(500).json({ error: innerErr.message });
          res.json({ ok: true, id: this.lastID });
        });
      }
    }
  );
});

app.get("/api/sales", (req, res) => {
  db.all("SELECT * FROM sales ORDER BY id DESC", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post("/api/sales", (req, res) => {
  const { customer_id, total_all, amount_paid, due, payment_method, cash_given_raw, change_all, profit, items } = req.body;

  db.run(
    `INSERT INTO sales (timestamp, customer_id, total_all, amount_paid, due, payment_method, cash_given_raw, change_all, profit, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [new Date().toISOString(), customer_id || null, total_all, amount_paid, due, payment_method, cash_given_raw, change_all, profit, due <= 0 ? "paid" : "owed"],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });

      const saleId = this.lastID;
      items.forEach(item => {
        db.run(
          "INSERT INTO sale_items (sale_id, product_id, qty, price, cost) VALUES (?, ?, ?, ?, ?)",
          [saleId, item.product_id, item.qty, item.price, item.cost]
        );

        db.run(
          "UPDATE products SET stock = MAX(stock - ?, 0) WHERE id = ?",
          [item.qty, item.product_id]
        );
      });

      res.json({ ok: true, saleId });
    }
  );
});

app.get("/api/reports/summary", (req, res) => {
  db.all(`
    SELECT
      (SELECT COALESCE(SUM(total_all), 0) FROM sales WHERE date(timestamp) = date('now')) AS sales_today,
      (SELECT COALESCE(SUM(profit), 0) FROM sales WHERE date(timestamp) = date('now')) AS profit_today,
      (SELECT COUNT(*) FROM products) AS total_products,
      (SELECT COUNT(*) FROM customers) AS total_customers,
      (SELECT COUNT(*) FROM sales WHERE date(timestamp) = date('now')) AS transactions_today
  `, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows[0]);
  });
});

app.get("/api/reports/low-stock", (req, res) => {
  db.all("SELECT * FROM products WHERE stock <= min_stock ORDER BY stock ASC", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
